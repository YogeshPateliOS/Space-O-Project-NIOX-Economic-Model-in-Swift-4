//
//  CalculationModel.swift
//  NIOXDesignIpd
//
//  Created by SOTSYS027 on 12/03/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import Foundation




struct ModelClass{
    var str8: String?
    var str9: String?
    var str10: String?
    var str11: String?
    var str14: String?
    var strC19: String?
    var strE19: String?
    var strI19: String?
    var strE20: String?
    var strC22: String?
    var strE22: String?
    var strI22: String?
    var strLabel12: String?
    var strLabel13: String?
    var strLabel15: String?
    var strLabelD19: String?
    var strLabelF19: String?
    var strLabelC20: String?
    var strLabelD20: String?
    var strLabelF20: String?
    var strLabelI20: String?
    var strLabelD22: String?
    var strLabelF22: String?
    var strLabelC23: String?
    var strLabelD23: String?
    var strLabelF23: String?
    var strLabelI23: String?
    var strLabelI26: String?
    var strLabelE26: String?
    var strLabelE27: String?
    var strLabelE28: String?
    var strLabelE29: String?
    var strLabelE30: String?
    var strLabelI27: String?
    var strLabelI28: String?
    var strLabelI29: String?
    var strLabelI30: String?
}

