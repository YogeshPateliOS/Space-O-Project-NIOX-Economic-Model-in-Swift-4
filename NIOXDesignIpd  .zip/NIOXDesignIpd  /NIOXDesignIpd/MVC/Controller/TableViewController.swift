//
//  Table1ViewController.swift
//  NIOXDesignIpd
//
//  Created by SOTSYS027 on 06/03/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class TableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIPickerViewDataSource, UIPickerViewDelegate {
    
    var arrdata = [String]()
    var ecoModel = [String]()
    var finalData = [String]()
    var finalData1 = [String]()
    var pickerData = [String]()
    var pickerView = UIPickerView()
    @IBOutlet weak var tableView: UITableView!
    let toolBar = UIToolbar()
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerView.delegate = self
        pickerData = [pickerTitle.first,pickerTitle.second,pickerTitle.third,pickerTitle.four]
        
        
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(red: 92/255, green: 216/255, blue: 255/255, alpha: 1)
        toolBar.sizeToFit()
        
        // Adding Button ToolBar
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneClick))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: nil)
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        // textField.inputAccessoryView = toolBar
        
        
        
        arrdata = [LabelMes.lblOne,LabelMes.lblTwo,LabelMes.lblThree,LabelMes.lblFour,LabelMes.lblFive,LabelMes.lblSix,LabelMes.lblSeven, LabelMes.footerOne]
        ecoModel = [LabelMes.firstTitle,LabelMes.lblElevan,LabelMes.lblTwe,LabelMes.lblThr,LabelMes.lblTotal]
        finalData = [LabelMes.f1,LabelMes.f2,LabelMes.f3, LabelMes.f4,LabelMes.f5, LabelMes.f6]
        finalData1 = [LabelMes.f7,LabelMes.f8,LabelMes.f9, LabelMes.f10,LabelMes.f11, LabelMes.f12]
    }
    @objc func doneClick(){
        pickerView.resignFirstResponder()
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return arrdata.count
        }else if section == 1{
            return ecoModel.count
        }else if section == 2{
            return ecoModel.count
        }else if section == 3{
            return finalData.count
        }else{
            return arrdata.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: Identifier.cellIdentifier, for: indexPath) as! TableViewCell
            cell.lblDetail.text = arrdata[indexPath.row]
            if indexPath.row == 0{
                cell.lblTxt.isHidden = true
            }else if indexPath.row == 1{
                cell.lblTxt.isHidden = true
                cell.txtField.placeholder = "0 - 7"
            }else if indexPath.row == 2{
                cell.lblTxt.text = "%"
                cell.lblTxt.textAlignment = .right
            }else if indexPath.row == 3{
                cell.lblTxt.text = "%"
                cell.lblTxt.textAlignment = .right
            }else if indexPath.row == 4{
                cell.txtField.isHidden = true
            }else if indexPath.row == 5{
                cell.txtField.isHidden = true
            }else if indexPath.row == 6{
                cell.lblTxt.isHidden = true
                cell.txtField.placeholder = "0 - 365"
            }else if indexPath.row == 7{
                cell.txtField.isHidden = true
                cell.lblDetail.textColor = UIColor.black
                cell.backgroundColor = UIColor.init(red: 239/256.0, green: 193/256.0, blue: 68/256.0, alpha: 1)
            }
            return cell
            
        }else if indexPath.section == 1{
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "EconomicModelCell", for: indexPath) as! EconomicModelCell
            cell1.lblDetail.text = ecoModel[indexPath.row]
            if indexPath.row == 0{
                cell1.txtField1.isHidden = true
                cell1.txtField2.isHidden = true
                cell1.lblTxt.text = LabelMes.secondTitle
                cell1.lblPrice.text = LabelMes.thirdTitle
                cell1.lblTxtTwo.text = LabelMes.fourTitle
                cell1.backgroundColor = UIColor.init(red: 206/256.0, green: 208/256.0, blue: 213/256.0, alpha: 1)
                
            }else if indexPath.row == 1{
                cell1.lblTxt.isHidden = true
                cell1.lblTxtTwo.isHidden = true
                cell1.lblPrice.text = "-"
            }else if indexPath.row == 2{
                cell1.txtField1.isHidden = true
                cell1.lblTxt.text = "0.0 %"
                cell1.lblPrice.text = "0"
                cell1.lblTxtTwo.isHidden = true
            }else if indexPath.row == 3{
                cell1.lblTxt.isHidden = true
                cell1.lblTxtTwo.isHidden = true
                cell1.lblPrice.text = "-"
            }else if indexPath.row == 4{
                cell1.txtField1.isHidden = true
                cell1.txtField2.isHidden = true
                cell1.lblPrice.text = "0"
                cell1.lblTxtTwo.text = "-"
                cell1.lblTxt.text = "-"
                cell1.lblDetail.textColor = UIColor.black
                cell1.backgroundColor = UIColor.init(red: 239/256.0, green: 193/256.0, blue: 68/256.0, alpha: 1)
            }
            return cell1
        }else if indexPath.section == 2{
            let cell3 = tableView.dequeueReusableCell(withIdentifier: "ModelCell", for: indexPath) as! ModelCell
            cell3.lblDetail.text = ecoModel[indexPath.row]
            if indexPath.row == 0{
                cell3.lblPrice.text = "Estimated Annual FeNO Tests"
                cell3.lblTxt.text = "Payment per test"
                cell3.txtField.isHidden = true
            }else if indexPath.row == 1{
                cell3.lblPrice.text = "-"
                cell3.lblTxt.isHidden = true
            }else if indexPath.row == 2{
                cell3.lblPrice.text = "-"
                cell3.lblTxt.text = "N/A"
                cell3.txtField.isHidden = true
            }else if indexPath.row == 3{
                cell3.lblPrice.text = "-"
                cell3.lblTxt.isHidden = true
            }else if indexPath.row == 4{
                cell3.lblPrice.text = "0"
                cell3.txtField.isHidden = true
                cell3.backgroundColor = UIColor.init(red: 239/256.0, green: 193/256.0, blue: 68/256.0, alpha: 1)
            }
            return cell3
        }else if indexPath.section == 3{
            let cell4 = tableView.dequeueReusableCell(withIdentifier: "FinalCell" , for: indexPath) as! FinalCell
            cell4.lblDetail.text = finalData[indexPath.row]
            cell4.lbldetail2.text = finalData1[indexPath.row]
            cell4.txtField1.isHidden = true
            cell4.txtFeild2.isHidden = true
            if indexPath.row == 0{
                cell4.txtField1.inputView = pickerView
                cell4.txtFeild2.inputView = pickerView
                cell4.txtField1.inputAccessoryView = toolBar
                cell4.txtFeild2.inputAccessoryView = toolBar
                cell4.txtField1.isHidden = false
                cell4.txtFeild2.isHidden = false
                cell4.lbltxt.isHidden = true
                cell4.lblTxt2.isHidden = true
            }else if indexPath.row == 1{
                cell4.lbltxt.text = "0"
            }else if indexPath.row == 2{
                cell4.lbltxt.text = "$0.0"
                cell4.lblTxt2.text = "$0.0"
            }else if indexPath.row == 3{
                cell4.lbltxt.text = "$0.0"
                cell4.lblTxt2.text = "$0.0"
            }else if indexPath.row == 4{
                cell4.lbltxt.text = "$0.0"
                cell4.lblTxt2.text = "$35.0"
            }else if indexPath.row == 5{
                cell4.lbltxt.backgroundColor = UIColor.init(red: 239/256.0, green: 193/256.0, blue: 68/256.0, alpha: 1)
                cell4.lbltxt.text = "-"
                cell4.lblTxt2.text = "-"
                cell4.lblTxt2.backgroundColor = UIColor.init(red: 239/256.0, green: 193/256.0, blue: 68/256.0, alpha: 1)
            }
            return cell4
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: Identifier.cellIdentifier, for: indexPath) as! TableViewCell
            cell.lblDetail.text = arrdata[indexPath.row]
            return cell
        }
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 20
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if section == 0{
            let headerView = UIView()
            headerView.backgroundColor = UIColor.init(red: 95/256.0, green: 148/256.0, blue: 198/256.0, alpha: 1)
            let label = UILabel(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 50))
            label.textColor = UIColor.white
            label.textAlignment = .center
            label.text = LabelMes.headerOne
            headerView.addSubview(label)
            return headerView
        }else if section == 1{
            let headerView = UIView()
            headerView.backgroundColor = UIColor.init(red: 95/256.0, green: 148/256.0, blue: 198/256.0, alpha: 1)
            let label = UILabel(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 50))
            label.textColor = UIColor.white
            label.textAlignment = .center
            label.text = "Economic Model"
            headerView.addSubview(label)
            return headerView
        }
        else{
            let headerView = UIView()
            headerView.backgroundColor = UIColor.init(red: 95/256.0, green: 148/256.0, blue: 198/256.0, alpha: 1)
            let label = UILabel(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 50))
            label.textColor = UIColor.white
            label.textAlignment = .center
            label.text = LabelMes.headerOne
            headerView.addSubview(label)
            return headerView
        }
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
