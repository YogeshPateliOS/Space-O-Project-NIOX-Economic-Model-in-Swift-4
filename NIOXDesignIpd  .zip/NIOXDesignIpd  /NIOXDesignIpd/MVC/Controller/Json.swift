//
//  Json.swift
//  NIOXDesignIpd
//
//  Created by SOTSYS027 on 14/03/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import Foundation


let jsonObject =
"""
{
        "students":[
        {
            "Name":"Yogesh",
            "CollegeName":"Sal College",
            "City":"Ahmedabad",
            "Age":"22"
        },
        {
            "Name":"Parth",
            "CollegeName":"Silveroak College",
            "City":"Surat",
            "Age":"22"
    
        },
        {
            "Name":"Sahdev",
            "CollegeName":"AIT College",
            "City":"Ahmedabad",
            "Age":"19"
    
        }
    ]
}
"""

