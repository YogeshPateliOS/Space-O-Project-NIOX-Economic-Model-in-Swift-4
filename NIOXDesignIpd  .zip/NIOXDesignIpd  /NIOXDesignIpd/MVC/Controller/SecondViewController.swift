//
//  SecondViewController.swift
//  NIOXDesignIpd
//
//  Created by SOTSYS027 on 07/03/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0
import IQKeyboardManagerSwift
import ParallaxHeader
class SecondViewController: UITableViewController, UITextFieldDelegate {
    
    // MARK: - Outlets
    var dataModel = ModelClass()
    var group = sheet2()
    var arrGroup = [sheet2]()
    @IBOutlet var textField: [UITextField]!
    @IBOutlet var Label: [UILabel]!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var topSpaceConstraint: NSLayoutConstraint!
    @IBOutlet weak var bottomSpaceConstraint: NSLayoutConstraint!
    @IBOutlet weak var btnRecorder: UIButton!
    @IBOutlet weak var btnIntial: UIButton!
    @IBOutlet var cell: [UITableViewCell]!
    let format = "%.2f"
    
    // MARK: - View LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        seperatorCell()
    //    static let first1 = "Test Kit 100"
      //  static let second1 = "Test Kit 300"
        //static let third1 = "Test Kit 500"
       // static let four1 = "TK 1000"
        // var dict5:[String:String] = ["lblI127":"$9.99", "lblI128":"$999.00"]
        // var dict6:[String:String] = ["lblI127":"$8.50", "lblI128":"$2,550.00"]
        // var dict7:[String:String] = ["lblI127":"$8.00", "lblI128":"$4,000.00"]
        // var dict8:[String:String] = ["lblI127":"$7.50", "lblI128":"$7,500.00"]
        arrGroup.append(sheet2(title: "5 Year SK 100", lblE27: "$7.25", lblE28: "$1500", lblE29: "$2225", lblI127: "", lblI128: ""))
        arrGroup.append(sheet2(title: "5 Year SK 300", lblE27: "$7.10", lblE28: "$1500", lblE29: "$3630", lblI127: "", lblI128: ""))
        arrGroup.append(sheet2(title: "5 Year SK 500", lblE27: "$7.00", lblE28: "$1500", lblE29: "$5000", lblI127: "", lblI128: ""))
        arrGroup.append(sheet2(title: "5 Year SK 1000", lblE27: "$6.90", lblE28: "$1500", lblE29: "$8400", lblI127: "", lblI128: ""))
        arrGroup.append(sheet2(title: "Test Kit 100", lblE27: "", lblE28: "", lblE29: "", lblI127: "$9.99", lblI128: "$999.00"))
        arrGroup.append(sheet2(title: "Test Kit 300", lblE27: "", lblE28: "", lblE29: "", lblI127: "$8.50", lblI128: "$2550.00"))
        arrGroup.append(sheet2(title: "Test Kit 500", lblE27: "", lblE28: "", lblE29: "", lblI127: "$8.00", lblI128: "$4000.00"))
        arrGroup.append(sheet2(title: "TK 1000", lblE27: "", lblE28: "", lblE29: "", lblI127: "$7.50", lblI128: "$7500.00"))
      
        navigationController?.navigationBar.isTranslucent = false
        
    }
    
    // MARK: - ScrollView Method
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView.contentOffset.y >= 0 {
            // scrolling down
            containerView.clipsToBounds = true
            bottomSpaceConstraint?.constant = -scrollView.contentOffset.y / 2
            topSpaceConstraint?.constant = scrollView.contentOffset.y / 2
        } else {
            // scrolling up
            topSpaceConstraint?.constant = scrollView.contentOffset.y
            containerView.clipsToBounds = false
        }
    }

    // MARK: - Methods
    // MARK: - Seperator Remove Cell
    func seperatorCell(){
        for cell in cell{
            cell.separatorInset = UIEdgeInsetsMake(0, 0, 0, .greatestFiniteMagnitude)
        }
        cell[12].backgroundColor = UIColor.clear
    }
    
    // MARK: - ModelValueAssign
    func assignValue(){
        dataModel.str8 = textField[0].text
        dataModel.str9 = textField[1].text
        dataModel.str10 = textField[2].text
        dataModel.str11 = textField[3].text
        dataModel.str14 = textField[4].text
        dataModel.strC19 = textField[5].text
        dataModel.strE19 = textField[6].text
        dataModel.strI19 = textField[7].text
        dataModel.strE20 = textField[8].text
        dataModel.strC22 = textField[9].text
        dataModel.strE22 = textField[10].text
        dataModel.strI22 = textField[11].text
    }
    
    // MARK: - intialLast
    func intialCalled(){
        dataModel.strLabelI23 = Label[14].text

        for (i,_) in arrGroup.enumerated(){
            if btnIntial.currentTitle == arrGroup[i].title{
                Label[16].text = arrGroup[i].lblE27
                Label[17].text = arrGroup[i].lblE28
                Label[18].text = arrGroup[i].lblE29
    
                let strInt:String = String((arrGroup[i].lblE29?.replacingOccurrences(of: "$", with: "").doubleValue)! / dataModel.strLabelI23!.doubleValue)
                dataModel.strLabelE30 = String(format: format, strInt.doubleValue)
                Label[19].text = dataModel.strLabelE30
            }
        }
        for (i,_) in arrGroup.enumerated(){
            if  btnRecorder.currentTitle == arrGroup[i].title
            {
                Label[21].text = arrGroup[i].lblI127
                Label[22].text = arrGroup[i].lblI128
                let strInt:String = String((arrGroup[i].lblI128?.replacingOccurrences(of: "$", with: "").doubleValue)! / dataModel.strLabelI23!.doubleValue)
                dataModel.strLabelI30 = String(format: format, strInt.doubleValue)
                Label[24].text = dataModel.strLabelI30
            }
            
        }
}
   
    // MARK: - Actions
    // MARK: - UITextFieldValueChanged
    @IBAction func textFieldValueChaged(_ sender: UITextField) {
        assignValue()
        dataModel.strLabel12 = String(dataModel.str8!.doubleValue * dataModel.str10!.doubleValue / 100 * dataModel.str11!.doubleValue / 100)
        Label[0].text = dataModel.strLabel12
        dataModel.strLabel13 = String(dataModel.strLabel12!.doubleValue * dataModel.str9!.doubleValue * 4)
        Label[1].text = dataModel.strLabel13
        dataModel.strLabel15 = String(dataModel.strLabel13!.doubleValue * dataModel.str14!.doubleValue * 12)
        Label[2].text = dataModel.strLabel15
        dataModel.strLabelD19 = String(dataModel.strC19!.doubleValue * dataModel.strLabel15!.doubleValue / 100)
        Label[3].text = dataModel.strLabelD19
        dataModel.strLabelF19 = String(dataModel.strLabelD19!.doubleValue * dataModel.strE19!.doubleValue / 100)
        Label[4].text = dataModel.strLabelF19
        let str = String(1 - dataModel.strC19!.doubleValue / 100 - dataModel.strC22!.doubleValue / 100)
        dataModel.strLabelC20 = String(str.doubleValue * 100)
        Label[5].text = dataModel.strLabelC20
        dataModel.strLabelD20 = String(dataModel.strLabelC20!.doubleValue * dataModel.strLabel15!.doubleValue / 100)
        Label[6].text = dataModel.strLabelD20
        dataModel.strLabelF20 = String(dataModel.strLabelD20!.doubleValue * dataModel.strE20!.doubleValue / 100)
        Label[7].text = dataModel.strLabelF20
        dataModel.strLabelD22 = String(dataModel.strC22!.doubleValue * dataModel.strLabel15!.doubleValue / 100)
        Label[9].text = dataModel.strLabelD22
        dataModel.strLabelC23 = String(dataModel.strC19!.doubleValue + dataModel.strLabelC20!.doubleValue + dataModel.strC22!.doubleValue)
        Label[11].text = dataModel.strLabelC23
        dataModel.strLabelD23 = String(dataModel.strLabelD19!.doubleValue + dataModel.strLabelD20!.doubleValue + dataModel.strLabelD22!.doubleValue)
        Label[12].text = dataModel.strLabelD23
        dataModel.strLabelF22 = String(dataModel.strLabelD22!.doubleValue * dataModel.strE22!.doubleValue / 100)
        Label[10].text = dataModel.strLabelF22
        dataModel.strLabelF23 = String(dataModel.strLabelF19!.doubleValue + dataModel.strLabelF20!.doubleValue + dataModel.strLabelF22!.doubleValue)
        Label[13].text = dataModel.strLabelF23
        let str11 = String(dataModel.strI19!.doubleValue * dataModel.strLabelF19!.doubleValue)
        let str12 = String(dataModel.strI22!.doubleValue * dataModel.strLabelF22!.doubleValue)
        let str13 = String(str11.doubleValue + str12.doubleValue)
        let mainFloat = String(str13.doubleValue / dataModel.strLabelF23!.doubleValue)
        dataModel.strLabelI23 = String(format: format, mainFloat.doubleValue)
        Label[14].text = dataModel.strLabelI23
        dataModel.strLabelE26 = dataModel.strLabelF23
        Label[15].text = dataModel.strLabelE26
        dataModel.strLabelI26 = dataModel.strLabelF23
        Label[20].text = dataModel.strLabelI26
        intialCalled()
    }
    
    // MARK: - intialClick
    @IBAction func btnIntialClick(_ sender: UIButton) {
        ActionSheetMultipleStringPicker.show(withTitle: "Test Kit", rows: [
            [pickerTitle.first, pickerTitle.second, pickerTitle.third, pickerTitle.four]
            ], initialSelection: [1], doneBlock: {
                picker, indexes, value in
                if let weather = value as? [Any], !weather.isEmpty {
                    self.btnIntial.setTitle(weather[0] as? String, for: .normal)
                    self.btnIntial.setTitleColor(UIColor.black, for: .normal)
                }
                self.intialCalled()
                return
        }, cancel: { ActionMultipleStringCancelBlock in return }, origin: sender)
    }
    
    // MARK: - RecorderClick
    @IBAction func btnRecorderClick(_ sender: UIButton) {
        ActionSheetMultipleStringPicker.show(withTitle: "Test Kit", rows: [
            [pickerTitle.first1, pickerTitle.second1, pickerTitle.third1, pickerTitle.four1]
            ], initialSelection: [1], doneBlock: {
                picker, indexes, values in
                if let weather = values as? [Any], !weather.isEmpty {
                    self.btnRecorder.setTitle(weather[0] as? String, for: .normal)
                    self.btnRecorder.setTitleColor(UIColor.black, for: .normal)
                }
                self.intialCalled()
                return
        }, cancel: { ActionMultipleStringCancelBlock in return }, origin: sender)
    }
    
    // MARK: - ResetClick
    @IBAction func resetBtnClick(_ sender: UIButton) {
        btnIntial.setTitle("Tap to select", for: .normal)
        btnIntial.setTitleColor(UIColor.init(red: 131/256.0, green: 132/256.0, blue: 132/256.0, alpha: 1), for: .normal)
        btnRecorder.setTitle("Tap to select", for: .normal)
        btnRecorder.setTitleColor(UIColor.init(red: 131/256.0, green: 132/256.0, blue: 132/256.0, alpha: 1), for: .normal)
        for txtname in textField{
            txtname.text = ""
        }
        for lbl in Label{
            lbl.text = "0.0"
            Label[8].text = "N/A"
            Label[16].text = "$0.0"
            Label[17].text = "$0.0"
            Label[18].text = "$0.0"
            Label[21].text = "$0.0"
            Label[22].text = "$0.0"
            Label[23].text = "$435.0"
        }
    }
    
    // MARK: - TableView Methods
    // MARK: - HeightRow Automatic
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
}

extension String{
    var stringValue : String { return self }
    var doubleValue : Double { return Double(stringValue) ?? 0 }
}


