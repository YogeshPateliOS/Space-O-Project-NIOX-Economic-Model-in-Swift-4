//
//  EconomicModelCell.swift
//  NIOXDesignIpd
//
//  Created by SOTSYS027 on 06/03/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class EconomicModelCell: UITableViewCell {

    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblDetail: UILabel!
    @IBOutlet weak var lblTxt: UILabel!
    @IBOutlet weak var txtField1: UITextField!
    @IBOutlet weak var txtField2: UITextField!
    @IBOutlet weak var lblTxtTwo: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
