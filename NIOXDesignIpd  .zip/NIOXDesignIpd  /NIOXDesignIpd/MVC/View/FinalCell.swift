//
//  FinalCell.swift
//  NIOXDesignIpd
//
//  Created by SOTSYS027 on 06/03/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class FinalCell: UITableViewCell {

    
    @IBOutlet weak var lblTxt2: UILabel!
    @IBOutlet weak var txtFeild2: UITextField!
    @IBOutlet weak var lbldetail2: UILabel!
    @IBOutlet weak var lbltxt: UILabel!
    @IBOutlet weak var txtField1: UITextField!
    @IBOutlet weak var lblDetail: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
