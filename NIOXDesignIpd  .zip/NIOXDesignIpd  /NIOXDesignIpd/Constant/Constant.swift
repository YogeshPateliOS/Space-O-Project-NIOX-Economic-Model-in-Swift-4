//
//  Constant.swift
//  NIOXDesignIpd
//
//  Created by SOTSYS027 on 06/03/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import Foundation
import UIKit
struct pickerTitle{
    static let first = "5 Year SK 100"
    static let second = "5 Year SK 300"
    static let third = "5 Year SK 500"
    static let four = "5 Year SK 1000"
    static let first1 = "Test Kit 100"
    static let second1 = "Test Kit 300"
    static let third1 = "Test Kit 500"
    static let four1 = "TK 1000"
}
struct LabelMes{
    static let headerOne = "PRACTICE OVERVIEW"
    static let footerOne = "Estimated total number of tests identified with NIOX per year"
    static let lblOne = "How many patients do you see in typical day?"
    static let lblTwo = "How many days do you practice each week? (at the location where device will resides)"
    static let lblThree = "In a typical day, what percentage of your patients are respiratory patients?"
    static let lblFour = "What percentage of your respiratory patients would you test with NIOX?"
    static let lblFive = "Estimated daily patients tested with NIOX:"
    static let lblSix = "Estimated Patients tested with NIOX per month(4 weeks)"
    static let lblSeven = "On average, how many times per year do you see this type of patient?"
    static let lblElevan = "Test Covered"
    static let lblTwe = "Not Covered"
    static let lblThr = "Pataient Pay/Not Covered Commerically insured"
    static let lblTotal = "Total"
    static let des = "-"
    static let zero = "0"
    static let firstTitle = "FeNO Converage"
    static let secondTitle = "% Payer mix"
    static let thirdTitle = "Annual Qty of test by payer mix"
    static let fourTitle = "Expected Test %"
    static let f1 = "Optimal initial Purchase option"
    static let f2 = "Estimated Annual test"
    static let f3 = "Cost per test"
    static let f4 = "NIOX New Device"
    static let f5 = "NIOX New Device & Sensor"
    static let f6 = "Tested Needed to Break Even"
    static let f7 = "Optimal Recorder test kit Option"
    static let f8 = "Estimated Annual test"
    static let f9 = "Cost per test"
    static let f10 = "Recorder test kit sensor cost"
    static let f11 = "Accessories or Extended Warrenty"
    static let f12 = "Tests Needed to Break Even"
    static let footerTitle = "For Demonstaration purpose only Assumption and projections are estimates only and do not guarentee converage or revenue Actual results may differ. No guarantee is provided or implied"
}

struct Identifier{
    static let cellIdentifier = "TableViewCell"
}

struct sheet2{
    
    var title:String?
    var lblE27:String?
    var lblE28:String?
    var lblE29:String?
    var lblI127:String?
    var lblI128:String?
    // var dict5:[String:String] = ["lblI127":"$9.99", "lblI128":"$999.00"]
   // var dict6:[String:String] = ["lblI127":"$8.50", "lblI128":"$2,550.00"]
   // var dict7:[String:String] = ["lblI127":"$8.00", "lblI128":"$4,000.00"]
   // var dict8:[String:String] = ["lblI127":"$7.50", "lblI128":"$7,500.00"]
}
    
//
//var arrData:[[String:sheet2]] = [["lblE27":"$7.25", "lblE28":"$1500", "lblE29":"$2225"],["lblE27":"$7.10", "lblE28":"$1500", "lblE29":"$3630"],["lblE27":"$7.00", "lblE28":"$1500", "lblE29":"$5000"],["lblE27":"$6.90", "lblE28":"$1500", "lblE29":"$8400"],["lblI127":"$9.99", "lblI128":"$999.00"],["lblI127":"$8.50", "lblI128":"$2550.00"],["lblI127":"$8.00", "lblI128":"$4000.00"],["lblI127":"$7.50", "lblI128":"$7500.00"]]

    
    
//    static let lblE127 = "$7.25"
//    static let lblE128 = "$1,500"
//    static var lblE129 = "$2,225"
//
//    static let lblE327 = "$7.10"
//    static let lblE328 = "$1,500"
//    static let lblE329 = "$3,630"
//
//    static let lblE527 = "$7.00"
//    static let lblE528 = "$1,500"
//    static let lblE529 = "$5,000"
//
//    static let lblE270 = "$6.90"
//    static let lblE280 = "$1,500"
//    static let lblE290 = "$8,400"
//
//    static let lblI127 = "$9.99"
//    static let lblI128 = "$999.00"
//
//    static let lblI327 = "$8.50"
//    static let lblI328 = "$2,550.00"
//
//    static let lblI527 = "$8.00"
//    static let lblI528 = "$4,000.00"
//
//    static let lblI270 = "$7.50"
//    static let lblI280 = "$7,500.00"
//
//    static let int1 = "1434"
//    static let int2 = "2985"
//    static let int3 = "4435"
//    static let int4 = "7935"

